/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package updateemploye;
   import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateEmployee {
    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/emp";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // JDBC variables for opening and managing connection
    private static Connection connection;

    public static void main(String[] args) {
        try {
            // Open a connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Take employee details as input from the user
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter Employee ID to update: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            System.out.print("Enter Employee Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Phone: ");
            String phone = scanner.nextLine();

            System.out.print("Enter Aadhar Number: ");
            String aadharNumber = scanner.nextLine();

            System.out.print("Enter Education: ");
            String education = scanner.nextLine();

            System.out.print("Enter Address: ");
            String address = scanner.nextLine();

            System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
            String dob = scanner.nextLine();

            System.out.print("Enter Joining Date (YYYY-MM-DD): ");
            String joinDate = scanner.nextLine();

            // Update data in the emp table
            String query = "UPDATE employee SET empName = ?, empPhoneNumber = ?, aadharNumber = ?, highestEducation = ?, address = ?, dateOfBirth = ?, joiningDate = ? WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, phone);
            preparedStatement.setString(3, aadharNumber);
            preparedStatement.setString(4, education);
            preparedStatement.setString(5, address);
            preparedStatement.setString(6, dob);
            preparedStatement.setString(7, joinDate);
            preparedStatement.setInt(8, id);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Employee information updated successfully!");
            } else {
                System.out.println("No employee found with ID " + id);
            }

            // Close the scanner
            scanner.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}