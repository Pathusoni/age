import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class NewEmpRoom2 extends javax.swing.JFrame {

    private List<String[]> roomData = new ArrayList<>();

    public NewEmpRoom2() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        // Initialize components
        jLabel1 = new JLabel();
        jButton1 = new JButton();
        jScrollPane1 = new JScrollPane();
        jTable1 = new JTable();
        jLabel2 = new JLabel();
        jTextField1 = new JTextField();
        jLabel3 = new JLabel();
        jCheckBox1 = new JCheckBox();
        jButton2 = new JButton();
        jSeparator1 = new JSeparator();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jTextField2 = new JTextField();
        jButton3 = new JButton();
        jLabel6 = new JLabel();
        jCheckBox2 = new JCheckBox();
        jButton4 = new JButton();
        jButton5 = new JButton();
        jSeparator2 = new JSeparator();
        jLabel7 = new JLabel();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("Employee Room Management");

        // Label configurations
        jLabel1.setFont(new Font("Tahoma", Font.BOLD, 36));
        jLabel1.setText("NEW EMP ROOM");

        jLabel2.setFont(new Font("Tahoma", Font.BOLD, 24));
        jLabel2.setText("ROOM NO");

        jLabel3.setFont(new Font("Tahoma", Font.BOLD, 24));
        jLabel3.setText("Active or Deactive");

        jLabel4.setFont(new Font("Tahoma", Font.BOLD, 24));
        jLabel4.setText("UPDATE & DELETE ROOM");

        jLabel5.setFont(new Font("Tahoma", Font.BOLD, 24));
        jLabel5.setText("ROOM NUMBER");

        jLabel6.setFont(new Font("Tahoma", Font.BOLD, 24));
        jLabel6.setText("Active or Deactive");

        jLabel7.setFont(new Font("Tahoma", Font.BOLD, 24));
        jLabel7.setText("FINALLY EMP ROOM");

        // Button configurations
        URL closeIconUrl = getClass().getResource("/Close.png");
        if (closeIconUrl != null) {
            jButton1.setIcon(new ImageIcon(closeIconUrl));
        } else {
            System.err.println("Resource not found: /Close.png");
        }
        jButton1.setFont(new Font("Tahoma", Font.BOLD, 18));
        jButton1.addActionListener(evt -> jButton1ActionPerformed(evt));

        URL saveIconUrl = getClass().getResource("/save.png");
        if (saveIconUrl != null) {
            jButton2.setIcon(new ImageIcon(saveIconUrl));
        } else {
            System.err.println("Resource not found: /save.png");
        }
        jButton2.setFont(new Font("Tahoma", Font.BOLD, 36));
        jButton2.setText("SAVE");
        jButton2.addActionListener(evt -> jButton2ActionPerformed(evt));

        URL searchIconUrl = getClass().getResource("/search.png");
        if (searchIconUrl != null) {
            jButton3.setIcon(new ImageIcon(searchIconUrl));
        } else {
            System.err.println("Resource not found: /search.png");
        }
        jButton3.setFont(new Font("Tahoma", Font.BOLD, 18));
        jButton3.setText("SEARCH");
        jButton3.addActionListener(evt -> jButton3ActionPerformed(evt));

        URL deleteIconUrl = getClass().getResource("/delete.png");
        if (deleteIconUrl != null) {
            jButton5.setIcon(new ImageIcon(deleteIconUrl));
        } else {
            System.err.println("Resource not found: /delete.png");
        }
        jButton5.setFont(new Font("Tahoma", Font.BOLD, 18));
        jButton5.setText("DELETE");
        jButton5.addActionListener(evt -> jButton5ActionPerformed(evt));

        jButton4.setFont(new Font("Tahoma", Font.BOLD, 18));
        jButton4.setText("UPDATE");
        jButton4.addActionListener(evt -> jButton4ActionPerformed(evt));

        // Checkbox configurations
        jCheckBox1.setFont(new Font("Tahoma", Font.BOLD, 24));
        jCheckBox1.setText("YES");

        jCheckBox2.setFont(new Font("Tahoma", Font.BOLD, 24));
        jCheckBox2.setText("YES");

        // Separator configurations
        jSeparator1.setBackground(Color.BLACK);
        jSeparator1.setForeground(Color.BLACK);

        jSeparator2.setBackground(Color.BLACK);
        jSeparator2.setForeground(Color.BLACK);

        // Table configuration
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object[][]{},
            new String[]{"Room Number", "Active Status"}
        ));
        jScrollPane1.setViewportView(jTable1);

        // Layout configuration
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jButton3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jCheckBox2)))
                                .addGap(0, 90, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton4)
                        .addGap(36, 36, 36)
                        .addComponent(jButton5)
                        .addGap(119, 119, 119))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jCheckBox1)
                        .addGap(29, 29, 29)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(353, 353, 353)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(251, 251, 251)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jCheckBox1)
                    .addComponent(jButton2))
                .addGap(16, 16, 16)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3)
                    .addComponent(jLabel6)
                    .addComponent(jCheckBox2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addGap(66, 66, 66)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(77, Short.MAX_VALUE))
        );

        pack();
    }

    private void jButton1ActionPerformed(ActionEvent evt) {
        int a = JOptionPane.showConfirmDialog(null, "Do you really want to exit the application?", "Select", JOptionPane.YES_NO_OPTION);
        if (a == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

   private void jButton2ActionPerformed(ActionEvent evt) {
    // Implement save functionality here
    String roomNo = jTextField1.getText();
    boolean isActive = jCheckBox1.isSelected();

    // Check if the room number field is not empty and the checkbox is selected
    if (!roomNo.isEmpty() && jCheckBox1.isSelected()) {
        roomData.add(new String[]{roomNo, isActive ? "Active" : "Inactive"});
        updateTable();
        JOptionPane.showMessageDialog(this, "Room saved successfully!");
        jTextField1.setText("");  // Clear the text field after saving
        jCheckBox1.setSelected(false);  // Deselect the checkbox after saving
    } else if (roomNo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a room number.");
    } else if (!jCheckBox1.isSelected()) {
        JOptionPane.showMessageDialog(this, "Please select the active status.");
    }
}


   private void jButton3ActionPerformed(ActionEvent evt) {
    String searchTerm = jTextField2.getText();
    if (!searchTerm.isEmpty()) {
        for (String[] room : roomData) {
            if (room[0].equals(searchTerm)) {
                jTextField2.setText(room[0]);
                jCheckBox2.setSelected(room[1].equals("Active"));
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Room not found.");
    } else {
        JOptionPane.showMessageDialog(this, "Please enter a room number to search.");
    }
}


   private void jButton4ActionPerformed(ActionEvent evt) {
    String roomNo = jTextField2.getText();
    boolean isActive = jCheckBox2.isSelected();

    if (!roomNo.isEmpty()) {
        boolean roomFound = false;
        for (int i = 0; i < roomData.size(); i++) {
            if (roomData.get(i)[0].equals(roomNo)) {
                roomData.set(i, new String[]{roomNo, isActive ? "Active" : "Inactive"});
                updateTable();
                JOptionPane.showMessageDialog(this, "Room updated successfully!");

                // Search for the updated room
                jTextField2.setText(roomNo);
                jCheckBox2.setSelected(isActive);
                
                roomFound = true;
                break;
            }
        }
        if (!roomFound) {
            JOptionPane.showMessageDialog(this, "Room not found.");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please enter a room number to update.");
    }
}


  private void jButton5ActionPerformed(ActionEvent evt) {
    String roomNo = jTextField2.getText();
    if (!roomNo.isEmpty()) {
        for (int i = 0; i < roomData.size(); i++) {
            if (roomData.get(i)[0].equals(roomNo)) {
                roomData.remove(i);
                updateTable();
                JOptionPane.showMessageDialog(this, "Room deleted successfully!");
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Room not found.");
    } else {
        JOptionPane.showMessageDialog(this, "Please enter a room number to delete.");
    }
}


    private void updateTable() {
        // Update table with the room data
        String[][] data = roomData.toArray(new String[0][]);
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            data,
            new String[]{"Room Number", "Active Status"}
        ));
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(NewEmpRoom2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            new NewEmpRoom2().setVisible(true);
        });
    }

    // Variables declaration
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;   
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
}
